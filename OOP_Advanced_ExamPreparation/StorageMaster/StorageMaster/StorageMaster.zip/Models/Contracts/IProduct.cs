﻿namespace StorageMaster.Models.Contracts
{
    public  interface IProduct
    {
        double Price { get; }

        double Weight { get; }
    }
}
