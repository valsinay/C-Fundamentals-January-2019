﻿namespace StorageMaster.Models.Vehicles
{
    public class Semi : Vehicle
    {
        private const int initialCapacity = 10;

        public Semi() 
            : base(initialCapacity)
        {
        }
    }
}
