﻿using StorageMaster.Factories;
using StorageMaster.Models.Contracts;
using StorageMaster.Models.Storages;
using StorageMaster.Models.Vehicles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StorageMaster.Core
{
    public class StorageMaster
    {
        private ProductFactory productFactory;
        private VehicleFactory vehicleFactory;
        private StorageFactory storageFactory;

        private Vehicle vehicle;
        private List<Product> products;
        private List<Storage> storages;

        public StorageMaster()
        {
            this.productFactory = new ProductFactory();
            this.storageFactory = new StorageFactory();
            this.vehicleFactory = new VehicleFactory();
            this.products = new List<Product>();
            this.storages = new List<Storage>();
        }

        public string AddProduct(string type, double price)
        {
            Product product = this.productFactory.CreateProduct(type, price);
            this.products.Add(product);

            return $"Added {type} to pool";
        }

        public string RegisterStorage(string type, string name)
        {
            Storage storage = this.storageFactory.CreateStorage(type, name);
            this.storages.Add(storage);

            return $"Registered {name}";
        }

        public string SelectVehicle(string storageName, int garageSlot)
        {
            Storage storage = storages.FirstOrDefault(x => x.Name == storageName);
            vehicle = storage.GetVehicle(garageSlot);

            return $"Selected {vehicle.GetType().Name}";
        }

        public string LoadVehicle(IEnumerable<string> productNames)
        {
            foreach (var name in productNames)
            {
                var product = this.products.FirstOrDefault(x => x.GetType().Name == name);

                if (product == null)
                {
                    throw new InvalidOperationException($"{name} is out of stock!");
                }

                product = this.products.Last(x => x.GetType().Name == name);
                vehicle.LoadProduct(product);
                products.Remove(product);

            }
            return $"Loaded {products.Count}/{productNames.Count()} products into {this.vehicle.GetType().Name}";
        }

        public string SendVehicleTo(string sourceName, int sourceGarageSlot, string destinationName)
        {
            Storage sourceStorage = storages.FirstOrDefault(x => x.Name == sourceName);
            if (sourceStorage==null)
            {
                throw new InvalidOperationException("Invalid source storage!");
            }
            vehicle = sourceStorage.GetVehicle(sourceGarageSlot);

            Storage destinationStorage = storages.FirstOrDefault(x => x.Name == destinationName);
            if (destinationStorage==null)
            {
                throw new InvalidOperationException("Invalid destination storage!");

            }
            int slot = -1;

            foreach (var item in destinationStorage.Garage)
            {
                if (item == null)
                {
                    slot = sourceStorage.SendVehicleTo(sourceGarageSlot, destinationStorage);
                    break;
                }
            }

            return $"Sent {vehicle.GetType().Name} to {destinationName} (slot {slot})";

        }

        public string UnloadVehicle(string storageName, int garageSlot)
        {
            Storage storage = this.storages.FirstOrDefault(x => x.Name == storageName);
            vehicle = storage.GetVehicle(garageSlot);
            int count = vehicle.Trunk.Count();
            vehicle.Unload();

            return $"Unloaded {count}/{count} products at {storageName}";
        }

        public string GetStorageStatus(string storageName)
        {
            //Storage storage = storages.FirstOrDefault(x => x.Name == storageName);
            throw new NotImplementedException();


        }

        public string GetSummary()
        {
            var builder = new StringBuilder();

            foreach (var item in storages.OrderByDescending(x=>x.TotalProductsPrice))
            {
                double total = item.Products.Sum(x=>x.Price);

                builder.AppendLine($"{item.Name}:")
                    .AppendLine($"Storage worth: ${total:f2}");

            }

            return builder.ToString().TrimEnd();
        }

    }
}
