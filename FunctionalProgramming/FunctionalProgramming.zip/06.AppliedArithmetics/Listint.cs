﻿namespace _06.AppliedArithmetics
{
    internal class Listint
    {
    }
}