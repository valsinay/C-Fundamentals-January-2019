﻿namespace ConsoleApp5
{
    public class TrafficLight
    {
        

    }
}
