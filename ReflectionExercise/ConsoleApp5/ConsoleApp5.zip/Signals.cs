﻿namespace ConsoleApp5
{
    public enum Signals
    {
        Red,
        Green,
        Yellow
    }
}
