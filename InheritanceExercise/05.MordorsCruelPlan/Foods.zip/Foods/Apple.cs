﻿namespace _05.MordorsCruelPlan.Foods
{
    public  class Apple : Food
    {
        public override int Happiness => 1;
    }
}
