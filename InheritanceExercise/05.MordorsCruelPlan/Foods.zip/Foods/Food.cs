﻿namespace _05.MordorsCruelPlan.Foods
{
    public class Food
    {
        public virtual int Happiness { get;}
    }
}
