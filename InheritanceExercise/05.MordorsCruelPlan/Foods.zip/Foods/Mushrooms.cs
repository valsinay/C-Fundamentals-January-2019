﻿namespace _05.MordorsCruelPlan.Foods
{
    public class Mushrooms:Food
    {
        public override int Happiness => -10;
    }
}
