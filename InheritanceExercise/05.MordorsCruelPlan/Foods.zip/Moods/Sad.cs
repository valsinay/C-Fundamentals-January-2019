﻿namespace _05.MordorsCruelPlan.Moods
{
    public class Sad : Mood
    {
        public override int From => -5;

        public override int To => 0;
    }
}
