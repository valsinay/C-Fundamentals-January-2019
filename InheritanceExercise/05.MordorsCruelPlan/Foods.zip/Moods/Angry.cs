﻿namespace _05.MordorsCruelPlan.Moods
{
    public class Angry : Mood
    {
        public override int From => int.MinValue;

        public override int To => -4;
    }
}
