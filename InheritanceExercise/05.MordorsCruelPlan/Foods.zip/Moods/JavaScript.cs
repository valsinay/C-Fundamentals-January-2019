﻿namespace _05.MordorsCruelPlan.Moods
{
    public class JavaScript : Mood
    {
        public override int From => 16;

        public override int To => int.MaxValue;
    }
}
