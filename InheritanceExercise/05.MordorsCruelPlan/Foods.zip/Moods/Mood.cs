﻿namespace _05.MordorsCruelPlan.Moods
{
   public class Mood
    {
        public virtual int From { get; set; }

        public virtual int To { get; set; }
    }
}
