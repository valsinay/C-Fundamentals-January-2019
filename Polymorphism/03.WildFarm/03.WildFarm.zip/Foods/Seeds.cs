﻿namespace _03.WildFarm.Foods
{
    public class Seeds : Food
    {
        public Seeds(int quantity)
            : base(quantity)
        {
        }
    }
}
