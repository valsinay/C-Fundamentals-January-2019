﻿namespace _03.WildFarm.Foods
{
    public class Fruit : Food
    {
        public Fruit(int quantity)
            : base(quantity)
        {
        }
    }
}
