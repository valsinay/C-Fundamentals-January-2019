﻿namespace _08.MilitaryElite.Contracts.Privates.SpecialisedSoldiers
{
    public interface IRepair
    {
        string PartName { get; }

        int HoursWorked { get; }
    }
}
