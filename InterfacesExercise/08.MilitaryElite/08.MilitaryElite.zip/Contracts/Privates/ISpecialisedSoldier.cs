﻿namespace _08.MilitaryElite.Contracts.Privates
{
    public interface ISpecialisedSoldier
    {
        string Corps { get; }
    }
}
