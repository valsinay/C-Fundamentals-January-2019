﻿namespace _08.MilitaryElite.Interfaces
{
    public interface IPrivate 
    {
        decimal Salary { get; }
    }
}
