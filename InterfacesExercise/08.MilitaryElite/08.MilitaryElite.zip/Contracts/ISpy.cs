﻿namespace _08.MilitaryElite.Interfaces
{
    public interface ISpy
    {
        int SpyCodeNumber { get; }
    }
}
