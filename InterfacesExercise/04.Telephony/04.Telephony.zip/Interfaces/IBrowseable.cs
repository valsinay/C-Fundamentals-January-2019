﻿namespace _04.Telephony.Interfaces
{
    public interface IBrowseable
    {
        string Browse(string url);
    }
}
