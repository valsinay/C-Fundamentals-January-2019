﻿namespace _04.Telephony
{
    using _04.Telephony.Interfaces;
    using System;
    using System.Linq;
    using System.Text;

    public class Smartphone : ICallable, IBrowseable
    {
        public string Call(string call)
        {
            bool digitsOnly = call.All(char.IsDigit);

            if (!digitsOnly)
            {
                throw new ArgumentException("Invalid number!");
            }
            else
            {
                var builder = new StringBuilder();
                builder.AppendLine($"Calling... {call}");
                return builder.ToString().TrimEnd();
            }
        }

        public string Browse(string url)
        {
            bool containsDigit = url.Any(char.IsDigit);

            if (containsDigit)
            {
                throw new ArgumentException("Invalid URL!");
            }
            else
            {
                var builder = new StringBuilder();
                builder.AppendLine($"Browsing: {url}!");

                return builder.ToString().TrimEnd();
            }
        }

       
    }
}
