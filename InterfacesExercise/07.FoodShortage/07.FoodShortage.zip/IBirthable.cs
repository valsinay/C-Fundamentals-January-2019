﻿namespace _07.FoodShortage
{
    using System;

    public interface IBirthable
    {
        DateTime BirthDate { get; }
    }
}
