﻿using System;

namespace _05.BorderControl
{
    public interface IBirthable
    {
        DateTime BirthDate { get; }
    }
}
